

package tercerpunto;

public class codigo3 {
    public static void main(String [] args){
        int costfijo=55000;
        int iva=5;
        int porutilidad=25;
        int porIva=(costfijo*5/100);
        int utilidades=(porutilidad*25/100);
        int totalcompra=porIva+utilidades+costfijo;
        System.out.println("el total de venta es: $"+totalcompra);
    
    }
    
}
