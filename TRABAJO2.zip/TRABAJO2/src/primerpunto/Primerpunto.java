
package primerpunto;


public class Primerpunto {

    public static void main(String[] args) {
        int x =50; 
        double y=x;
        System.out.printf("x = %d\n", x );
        System.out.printf("El valor de %d + %d es %d\n", x, x, ( x + x ) );
        System.out.printf("El valor de %d / 2 = %.2f\n", x, (y/2));
        System.out.printf("El valor de %d mod 3 = %d\n", x, x%3 );

        

        
    }
    
}
