
package segundopunto;


public class codigo2 {
    public static void main(String [] args){
        double num1=67;
        double num2=14;
        double num3=32;
        double suma=(num1+num2+num3); 
        double prom=(suma/3); 
        double multi=(num1*num2*num3); 
        double divi=(num1/num2/num3);  
        double modulo=(num1%num2%num3);
        System.out.printf("La suma de los numeros es:%.2f \n",suma);
        System.out.printf("el promedio de los numeros es:%.2f \n",prom);
        System.out.printf("La producto de los numeros es:%.2f \n",multi);
        System.out.printf("La cociente de los numeros es: %.2f \n",divi);
        System.out.printf("El modulo de los numeros:%.2f \n",modulo);
        
        
        
    }
    
}
