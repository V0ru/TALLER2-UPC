
package cuartopunto;

public class codigo4 {
    public static void main(String [] args){
        int numviajes=10; //numero de dias del viaje 
        int totalkilo=20; //total de kilometros conducidos por dia 
        //caclcular costo total del costo de gasolina del viaje
        int costogasolina=4500; //costo por litro de gasolina 
        int litrogasdiario=10; //litro de gasto de gaoslina diario 
        int totalgasolina=(4500*10); //total del costo de gasolina del viaje //+
        
        //calcular total del promedio de kilometro por dia
        float promkilogasolina=totalkilo/litrogasdiario; //promedio de kilometro por litro de gasolina 
        
        //calcular total a pagar en establecimiento
        int pagoestablecimiento=15000; //pago por estacionamiento por dia 
        int totalpagoestacionamiento=pagoestablecimiento*numviajes; //+
        
        //calcular el toral del pago de peajes en el viaje
        int valorpeaje=3500;
        int peajesdiarios=3; 
        int totalpeaje=(valorpeaje*peajesdiarios*numviajes); //total del pago de peajes por dia del viaje //+
        
        //calcular valor total del viaje
        int costotatal=(totalgasolina+totalpagoestacionamiento+totalpeaje);
        System.out.println("El costo total del viaje es: "+costotatal);
        
        
    }
    
}
